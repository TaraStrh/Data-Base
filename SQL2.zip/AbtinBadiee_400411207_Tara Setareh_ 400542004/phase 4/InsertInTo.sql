use Project

INSERT INTO Users (username, first_name, last_name, city, password, gender, sender_id) VALUES
('user1', 'John', 'Doe', 'New York', 'password1', 'Male','user2'),
('user2', 'Jane', 'Doe', 'Los Angeles', 'password2', 'Female','user1'),
('user3', 'Mike', 'Smith', 'Chicago', 'password3', 'Male','user1'),
('user4', 'Anna', 'Jones', 'Houston', 'password4', 'Female','user1'),
('user5', 'Chris', 'Brown', 'Phoenix', 'password5', 'Male','user1'),
('user6', 'Pat', 'Davis', 'Philadelphia', 'password6', 'Other','user1'),
('user7', 'Alex', 'Garcia', 'San Antonio', 'password7', 'Female','user1'),
('user8', 'Taylor', 'Wilson', 'San Diego', 'password8', 'Male','user1'),
('user9', 'Jordan', 'Martinez', 'Dallas', 'password9', 'Other','user1'),
('user10', 'Sam', 'Anderson', 'San Jose', 'password10', 'Female','user1');

INSERT INTO Highlights (highlight_id, user_id, publication_time, highlight_type, likers_list) VALUES
(1, 'user1', '2023-01-01 10:00:00', 'video', 'user2,user3'),
(2, 'user2', '2023-01-02 11:00:00', 'image', 'user1,user4'),
(3, 'user3', '2023-01-03 12:00:00', 'text', 'user2,user5'),
(4, 'user4', '2023-01-04 13:00:00', 'video', 'user3,user6'),
(5, 'user5', '2023-01-05 14:00:00', 'image', 'user4,user7'),
(6, 'user6', '2023-01-06 15:00:00', 'text', 'user5,user8'),
(7, 'user7', '2023-01-07 16:00:00', 'video', 'user6,user9'),
(8, 'user8', '2023-01-08 17:00:00', 'image', 'user7,user10'),
(9, 'user9', '2023-01-09 18:00:00', 'text', 'user8,user1'),
(10, 'user10', '2023-01-10 19:00:00', 'video', 'user9,user2');

INSERT INTO HighlightAccesses (access_date, username, highlight_id) VALUES
('2023-01-01 10:30:00', 'user1', 1),
('2023-01-02 11:30:00', 'user2', 2),
('2023-01-03 12:30:00', 'user3', 3),
('2023-01-04 13:30:00', 'user4', 4),
('2023-01-05 14:30:00', 'user5', 5),
('2023-01-06 15:30:00', 'user6', 6),
('2023-01-07 16:30:00', 'user7', 7),
('2023-01-08 17:30:00', 'user8', 8),
('2023-01-09 18:30:00', 'user9', 9),
('2023-01-10 19:30:00', 'user10', 10);

INSERT INTO Stories (story_id, highlight_id, end_date, story_type, location, view_count, publication_datetime, user_id) VALUES
(1, 1, '2023-01-02 10:00:00', 'photo', 'New York', 100, '2023-01-01 10:00:00', 'user1'),
(2, 2, '2023-01-03 11:00:00', 'video', 'Los Angeles', 200, '2023-01-02 11:00:00', 'user2'),
(3, 3, '2023-01-04 12:00:00', 'text', 'Chicago', 150, '2023-01-03 12:00:00', 'user3'),
(4, 4, '2023-01-05 13:00:00', 'photo', 'Houston', 250, '2023-01-04 13:00:00', 'user4'),
(5, 5, '2023-01-06 14:00:00', 'video', 'Phoenix', 300, '2023-01-05 14:00:00', 'user5'),
(6, 6, '2023-01-07 15:00:00', 'text', 'Philadelphia', 180, '2023-01-06 15:00:00', 'user6'),
(7, 7, '2023-01-08 16:00:00', 'photo', 'San Antonio', 220, '2023-01-07 16:00:00', 'user7'),
(8, 8, '2023-01-09 17:00:00', 'video', 'San Diego', 270, '2023-01-08 17:00:00', 'user8'),
(9, 9, '2023-01-10 18:00:00', 'text', 'Dallas', 190, '2023-01-09 18:00:00', 'user9'),
(10, 10, '2023-01-11 19:00:00', 'photo', 'San Jose', 230, '2023-01-10 19:00:00', 'user10');

INSERT INTO StoryLikes (like_date, username, story_id) VALUES
('2023-01-01 11:00:00', 'user2', 1),
('2023-01-02 12:00:00', 'user3', 2),
('2023-01-03 13:00:00', 'user4', 3),
('2023-01-04 14:00:00', 'user5', 4),
('2023-01-05 15:00:00', 'user6', 5),
('2023-01-06 16:00:00', 'user7', 6),
('2023-01-07 17:00:00', 'user8', 7),
('2023-01-08 18:00:00', 'user9', 8),
('2023-01-09 19:00:00', 'user10', 9),
('2023-01-10 20:00:00', 'user1', 10);

INSERT INTO StoryAccesses (access_date, username, story_id) VALUES
('2023-01-01 10:30:00', 'user1', 1),
('2023-01-02 11:30:00', 'user2', 2),
('2023-01-03 12:30:00', 'user3', 3),
('2023-01-04 13:30:00', 'user4', 4),
('2023-01-05 14:30:00', 'user5', 5),
('2023-01-06 15:30:00', 'user6', 6),
('2023-01-07 16:30:00', 'user7', 7),
('2023-01-08 17:30:00', 'user8', 8),
('2023-01-09 18:30:00', 'user9', 9),
('2023-01-10 19:30:00', 'user10', 10);

INSERT INTO UserContacts (user_contact_number, user_id, contact_number) VALUES
('contact1', 'user1', '555-1111'),
('contact2', 'user2', '555-2222'),
('contact3', 'user3', '555-3333'),
('contact4', 'user4', '555-4444'),
('contact5', 'user5', '555-5555'),
('contact6', 'user6', '555-6666'),
('contact7', 'user7', '555-7777'),
('contact8', 'user8', '555-8888'),
('contact9', 'user9', '555-9999'),
('contact10', 'user10', '555-1010');

INSERT INTO UserEmails (user_email, user_id) VALUES
('user1@example.com', 'user1'),
('user2@example.com', 'user2'),
('user3@example.com', 'user3'),
('user4@example.com', 'user4'),
('user5@example.com', 'user5'),
('user6@example.com', 'user6'),
('user7@example.com', 'user7'),
('user8@example.com', 'user8'),
('user9@example.com', 'user9'),
('user10@example.com', 'user10');


INSERT INTO Posts (post_id, poster_id, post_type, post_content, publication_date, comment_count, like_count, post_count, location, username) VALUES
(1, 'user1', 'text', 'First post', '2023-01-01 09:00:00', 5, 10, 1, 'New York', 'user1'),
(2, 'user2', 'image', 'Second post', '2023-01-02 09:00:00', 8, 15, 2, 'Los Angeles', 'user2'),
(3, 'user3', 'video', 'Third post', '2023-01-03 09:00:00', 3, 7, 3, 'Chicago', 'user3'),
(4, 'user4', 'text', 'Fourth post', '2023-01-04 09:00:00', 6, 12, 4, 'Houston', 'user4'),
(5, 'user5', 'image', 'Fifth post', '2023-01-05 09:00:00', 7, 14, 5, 'Phoenix', 'user5'),
(6, 'user6', 'video', 'Sixth post', '2023-01-06 09:00:00', 2, 5, 6, 'Philadelphia', 'user6'),
(7, 'user7', 'text', 'Seventh post', '2023-01-07 09:00:00', 4, 8, 7, 'San Antonio', 'user7'),
(8, 'user8', 'image', 'Eighth post', '2023-01-08 09:00:00', 9, 18, 8, 'San Diego', 'user8'),
(9, 'user9', 'video', 'Ninth post', '2023-01-09 09:00:00', 1, 3, 9, 'Dallas', 'user9'),
(10, 'user10', 'text', 'Tenth post', '2023-01-10 09:00:00', 10, 20, 10, 'San Jose', 'user10');

INSERT INTO PostLikes (like_date, username, post_id) VALUES
('2023-01-01 10:00:00', 'user2', 1),
('2023-01-02 10:00:00', 'user3', 2),
('2023-01-03 10:00:00', 'user4', 3),
('2023-01-04 10:00:00', 'user5', 4),
('2023-01-05 10:00:00', 'user6', 5),
('2023-01-06 10:00:00', 'user7', 6),
('2023-01-07 10:00:00', 'user8', 7),
('2023-01-08 10:00:00', 'user9', 8),
('2023-01-09 10:00:00', 'user10', 9),
('2023-01-10 10:00:00', 'user1', 10);

INSERT INTO PostAccesses (access_date, username, post_id) VALUES
('2023-01-01 10:30:00', 'user1', 1),
('2023-01-02 10:30:00', 'user2', 2),
('2023-01-03 10:30:00', 'user3', 3),
('2023-01-04 10:30:00', 'user4', 4),
('2023-01-05 10:30:00', 'user5', 5),
('2023-01-06 10:30:00', 'user6', 6),
('2023-01-07 10:30:00', 'user7', 7),
('2023-01-08 10:30:00', 'user8', 8),
('2023-01-09 10:30:00', 'user9', 9),
('2023-01-10 10:30:00', 'user10', 10);

INSERT INTO Notes (note_id, content, publication_date, end_date, username, creator_id) VALUES
(1, 'Note content 1', '2023-01-01 08:00:00', '2023-01-02 08:00:00', 'user1', 'user1'),
(2, 'Note content 2', '2023-01-02 08:00:00', '2023-01-03 08:00:00', 'user2', 'user2'),
(3, 'Note content 3', '2023-01-03 08:00:00', '2023-01-04 08:00:00', 'user3', 'user3'),
(4, 'Note content 4', '2023-01-04 08:00:00', '2023-01-05 08:00:00', 'user4', 'user4'),
(5, 'Note content 5', '2023-01-05 08:00:00', '2023-01-06 08:00:00', 'user5', 'user5'),
(6, 'Note content 6', '2023-01-06 08:00:00', '2023-01-07 08:00:00', 'user6', 'user6'),
(7, 'Note content 7', '2023-01-07 08:00:00', '2023-01-08 08:00:00', 'user7', 'user7'),
(8, 'Note content 8', '2023-01-08 08:00:00', '2023-01-09 08:00:00', 'user8', 'user8'),
(9, 'Note content 9', '2023-01-09 08:00:00', '2023-01-10 08:00:00', 'user9', 'user9'),
(10, 'Note content 10', '2023-01-10 08:00:00', '2023-01-11 08:00:00', 'user10', 'user10');

INSERT INTO NoteAccesses (access_date, username, note_id) VALUES
('2023-01-01 08:30:00', 'user1', 1),
('2023-01-02 08:30:00', 'user2', 2),
('2023-01-03 08:30:00', 'user3', 3),
('2023-01-04 08:30:00', 'user4', 4),
('2023-01-05 08:30:00', 'user5', 5),
('2023-01-06 08:30:00', 'user6', 6),
('2023-01-07 08:30:00', 'user7', 7),
('2023-01-08 08:30:00', 'user8', 8),
('2023-01-09 08:30:00', 'user9', 9),
('2023-01-10 08:30:00', 'user10', 10);

INSERT INTO UserProfiles (page_id, username, follower_count, following_count, biography) VALUES
(1, 'user1', 100, 50, 'Bio of user1'),
(2, 'user2', 150, 60, 'Bio of user2'),
(3, 'user3', 200, 70, 'Bio of user3'),
(4, 'user4', 250, 80, 'Bio of user4'),
(5, 'user5', 300, 90, 'Bio of user5'),
(6, 'user6', 350, 100, 'Bio of user6'),
(7, 'user7', 400, 110, 'Bio of user7'),
(8, 'user8', 450, 120, 'Bio of user8'),
(9, 'user9', 500, 130, 'Bio of user9'),
(10, 'user10', 550, 140, 'Bio of user10');

INSERT INTO Tags (tag_id, tag_date, username, page_id, page) VALUES
(1, '2023-01-01 07:00:00', 'user1', 1, 'Page 1 content'),
(2, '2023-01-02 07:00:00', 'user2', 2, 'Page 2 content'),
(3, '2023-01-03 07:00:00', 'user3', 3, 'Page 3 content'),
(4, '2023-01-04 07:00:00', 'user4', 4, 'Page 4 content'),
(5, '2023-01-05 07:00:00', 'user5', 5, 'Page 5 content'),
(6, '2023-01-06 07:00:00', 'user6', 6, 'Page 6 content'),
(7, '2023-01-07 07:00:00', 'user7', 7, 'Page 7 content'),
(8, '2023-01-08 07:00:00', 'user8', 8, 'Page 8 content'),
(9, '2023-01-09 07:00:00', 'user9', 9, 'Page 9 content'),
(10, '2023-01-10 07:00:00', 'user10', 10, 'Page 10 content');

INSERT INTO Reels (reel_id, view_count, like_count, comment_count, publication_date, reel_content, username, creator_id) VALUES
(1, 100, 10, 5, '2023-01-01 06:00:00', 'Reel content 1', 'user1', 'user1'),
(2, 200, 20, 10, '2023-01-02 06:00:00', 'Reel content 2', 'user2', 'user2'),
(3, 300, 30, 15, '2023-01-03 06:00:00', 'Reel content 3', 'user3', 'user3'),
(4, 400, 40, 20, '2023-01-04 06:00:00', 'Reel content 4', 'user4', 'user4'),
(5, 500, 50, 25, '2023-01-05 06:00:00', 'Reel content 5', 'user5', 'user5'),
(6, 600, 60, 30, '2023-01-06 06:00:00', 'Reel content 6', 'user6', 'user6'),
(7, 700, 70, 35, '2023-01-07 06:00:00', 'Reel content 7', 'user7', 'user7'),
(8, 800, 80, 40, '2023-01-08 06:00:00', 'Reel content 8', 'user8', 'user8'),
(9, 900, 90, 45, '2023-01-09 06:00:00', 'Reel content 9', 'user9', 'user9'),
(10, 1000, 100, 50, '2023-01-10 06:00:00', 'Reel content 10', 'user10', 'user10');

INSERT INTO ReelLikes (like_date, username, reel_id) VALUES
('2023-01-01 06:30:00', 'user2', 1),
('2023-01-02 06:30:00', 'user3', 2),
('2023-01-03 06:30:00', 'user4', 3),
('2023-01-04 06:30:00', 'user5', 4),
('2023-01-05 06:30:00', 'user6', 5),
('2023-01-06 06:30:00', 'user7', 6),
('2023-01-07 06:30:00', 'user8', 7),
('2023-01-08 06:30:00', 'user9', 8),
('2023-01-09 06:30:00', 'user10', 9),
('2023-01-10 06:30:00', 'user1', 10);

INSERT INTO ReelAccesses (access_date, username, reel_id) VALUES
('2023-01-01 06:30:00', 'user1', 1),
('2023-01-02 06:30:00', 'user2', 2),
('2023-01-03 06:30:00', 'user3', 3),
('2023-01-04 06:30:00', 'user4', 4),
('2023-01-05 06:30:00', 'user5', 5),
('2023-01-06 06:30:00', 'user6', 6),
('2023-01-07 06:30:00', 'user7', 7),
('2023-01-08 06:30:00', 'user8', 8),
('2023-01-09 06:30:00', 'user9', 9),
('2023-01-10 06:30:00', 'user10', 10);

INSERT INTO FriendRequests (request_date, receiver_id, sender_id) VALUES
('2023-01-01 09:00:00', 'user1', 'user2'),
('2023-01-02 09:00:00', 'user2', 'user3'),
('2023-01-03 09:00:00', 'user3', 'user4'),
('2023-01-04 09:00:00', 'user4', 'user5'),
('2023-01-05 09:00:00', 'user5', 'user6'),
('2023-01-06 09:00:00', 'user6', 'user7'),
('2023-01-07 09:00:00', 'user7', 'user8'),
('2023-01-08 09:00:00', 'user8', 'user9'),
('2023-01-09 09:00:00', 'user9', 'user10'),
('2023-01-10 09:00:00', 'user10', 'user1');

INSERT INTO RequestResponses (response_status, response_date, receiver_id, sender_id) VALUES
('accepted', '2023-01-01 10:00:00', 'user1', 'user2'),
('rejected', '2023-01-02 10:00:00', 'user2', 'user3'),
('accepted', '2023-01-03 10:00:00', 'user3', 'user4'),
('rejected', '2023-01-04 10:00:00', 'user4', 'user5'),
('accepted', '2023-01-05 10:00:00', 'user5', 'user6'),
('rejected', '2023-01-06 10:00:00', 'user6', 'user7'),
('accepted', '2023-01-07 10:00:00', 'user7', 'user8'),
('rejected', '2023-01-08 10:00:00', 'user8', 'user9'),
('accepted', '2023-01-09 10:00:00', 'user9', 'user10'),
('rejected', '2023-01-10 10:00:00', 'user10', 'user1');
