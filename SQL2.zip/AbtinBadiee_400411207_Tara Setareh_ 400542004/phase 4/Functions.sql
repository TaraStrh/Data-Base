use Project
-- Function to get the number of followers for a user:
CREATE FUNCTION fn_get_follower_count(@username VARCHAR(100))
RETURNS INT
AS
BEGIN
    DECLARE @follower_count INT;
    SELECT @follower_count = COUNT(*)
    FROM Followers
    WHERE followed_id = @username;
    RETURN @follower_count;
END;


--Function to calculate the age of a user based on birthdate:
CREATE FUNCTION fn_get_age(@birthdate DATE)
RETURNS INT
AS
BEGIN
    RETURN DATEDIFF(YEAR, @birthdate, GETDATE());
END;

--Function to get the total number of posts by a user:
CREATE FUNCTION fn_get_post_count(@username VARCHAR(100))
RETURNS INT
AS
BEGIN
    DECLARE @post_count INT;
    SELECT @post_count = COUNT(*)
    FROM Posts
    WHERE poster_id = @username;
    RETURN @post_count;
END;

