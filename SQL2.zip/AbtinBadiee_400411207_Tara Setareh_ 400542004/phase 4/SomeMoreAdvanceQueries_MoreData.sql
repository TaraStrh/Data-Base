USE Project

INSERT INTO Users (username, first_name, last_name, city, password, gender) VALUES 
('user100', 'Alice', 'Smith', 'New York', 'passwordAlice', 'Female'),
('user105', 'Bob', 'Johnson', 'Los Angeles', 'passwordBob', 'Male'),
('user102', 'Charlie', 'Williams', 'Chicago', 'passwordCharlie', 'Male'),
('user103', 'Daisy', 'Brown', 'Houston', 'passwordDaisy', 'Female'),
('user104', 'Eve', 'Davis', 'Phoenix', 'passwordEve', 'Female');


INSERT INTO Highlights (highlight_id, user_id, publication_time, highlight_type, likers_list) VALUES 
(103, 'user100', '2024-01-01 10:00:00', 'photo', 'user101,user102'),
(101, 'user105', '2024-02-01 11:00:00', 'video', 'user100,user103'),
(102, 'user102', '2024-03-01 12:00:00', 'text', 'user104,user101');


INSERT INTO Stories (story_id, highlight_id, end_date, story_type, location, view_count, publication_datetime, user_id) VALUES 
(100, 100, '2024-01-02 10:00:00', 'image', 'New York', 150, '2024-01-01 10:00:00', 'user100'),
(101, 101, '2024-02-02 11:00:00', 'image', 'Los Angeles', 200, '2024-02-01 11:00:00', 'user101'),
(102, 102, '2024-03-02 12:00:00', 'image', 'Chicago', 250, '2024-03-01 12:00:00', 'user102');

INSERT INTO UserProfiles (page_id, username, follower_count, following_count, biography) VALUES 
(100, 'user100', 100, 150, 'This is Alices profile.'),
(101, 'user101', 200, 250, 'This is Bobs profile.'),
(102, 'user102', 300, 350, 'This is Charlies profile.');


INSERT INTO PostComments (comment_id, post_id, commenter_id, comment_text, comment_date) VALUES
(1, 1, 'user100', 'This is a comment by Alice.', '2024-05-01 10:00:00'),
(2, 1, 'user101', 'This is a comment by Bob.', '2024-05-02 11:00:00'),
(3, 2, 'user102', 'This is a comment by Charlie.', '2024-05-03 12:00:00'),
(4, 2, 'user103', 'This is a comment by Daisy.', '2024-05-04 13:00:00'),
(5, 3, 'user104', 'This is a comment by Eve.', '2024-05-05 14:00:00');

INSERT INTO Followers (follower_id, followed_id, follow_date) VALUES
('user100', 'user101', '2024-01-01 10:00:00'),
('user101', 'user102', '2024-01-02 11:00:00'),
('user102', 'user103', '2024-01-03 12:00:00'),
('user103', 'user104', '2024-01-04 13:00:00'),
('user104', 'user100', '2024-01-05 14:00:00');

--1
-- Retrieve Usernames of All Users who have Created Highlights
SELECT DISTINCT user_id FROM Highlights;

--2
--Retrieve Highlight Details Along with the Usernames of Users who Liked Them
SELECT h.highlight_id, h.user_id, h.publication_time, h.highlight_type, u.username AS liker
FROM Highlights h
JOIN Users u ON CHARINDEX(',' + CAST(u.username AS VARCHAR(100)) + ',', ',' + CAST(h.likers_list AS VARCHAR(MAX)) + ',') > 0;

--3
--Retrieve the Latest Highlight Created by Each User
SELECT h.user_id, h.highlight_id, h.publication_time
FROM Highlights h
JOIN (
    SELECT user_id, MAX(publication_time) AS latest_time
    FROM Highlights
    GROUP BY user_id
) hl ON h.user_id = hl.user_id AND h.publication_time = hl.latest_time;

--4
--Retrieve All Stories and Their Corresponding Highlight Information
SELECT s.story_id, s.highlight_id, s.end_date, s.story_type, s.location, s.view_count, s.publication_datetime, s.user_id,
       h.highlight_type, h.publication_time
FROM Stories s
JOIN Highlights h ON s.highlight_id = h.highlight_id;


--5
--Retrieve User Profiles Along with the Number of Highlights Each User Has Created
SELECT u.username, up.follower_count, up.following_count, CAST(up.biography AS VARCHAR(MAX)) AS biography, COUNT(h.highlight_id) AS highlight_count
FROM Users u
JOIN UserProfiles up ON u.username = up.username
LEFT JOIN Highlights h ON u.username = h.user_id
GROUP BY u.username, up.follower_count, up.following_count, CAST(up.biography AS VARCHAR(MAX));


--6
--Retrieve All Highlights That Have Been Liked by a Specific User
SELECT h.highlight_id, h.user_id, h.publication_time, h.highlight_type
FROM Highlights h
JOIN Users u ON CHARINDEX(',' + CAST('user100' AS VARCHAR(100)) + ',', ',' + CAST(h.likers_list AS VARCHAR(MAX)) + ',') > 0
WHERE u.username = 'user100';


--7
--Retrieve All Users Who Have Accessed a Specific Highlight
SELECT ha.username, ha.access_date
FROM HighlightAccesses ha
WHERE ha.highlight_id = 1;


--8
--Retrieve All Stories Published in a Specific Location
SELECT * FROM Stories
WHERE location = 'New York';


--9
--Retrieve the Total Number of Likes for Each Story
SELECT s.story_id, COUNT(sl.username) AS total_likes
FROM Stories s
LEFT JOIN StoryLikes sl ON s.story_id = sl.story_id
GROUP BY s.story_id;



--10
--Retrieve Users and Their Posts with More Than a Certain Number of Likes
SELECT p.post_id, p.poster_id, p.post_type, p.post_content, p.publication_date, p.like_count
FROM Posts p
WHERE p.like_count > 10;

--11
--Retrieve All Friend Requests Sent by a Specific User
SELECT * FROM FriendRequests
WHERE sender_id = 'user1';


--12
--Retrieve All Friend Requests Received by a Specific User
SELECT * FROM FriendRequests
WHERE receiver_id = 'user1';


--13
--Retrieve All Responses to Friend Requests Sent by a Specific User
SELECT rr.receiver_id, rr.sender_id, rr.response_status, rr.response_date
FROM RequestResponses rr
WHERE rr.sender_id = 'user1';


--13
--Retrieve the Number of Comments on Each Post
SELECT p.post_id, COUNT(pc.comment_id) AS comment_count
FROM Posts p
LEFT JOIN PostComments pc ON p.post_id = pc.post_id
GROUP BY p.post_id;


--14
-- Retrieve All Users Who Have Viewed a Specific Reel
SELECT ra.username, ra.access_date
FROM ReelAccesses ra
WHERE ra.reel_id = 1;

--15
-- Retrieve All Notes Created by a Specific User
SELECT * FROM Notes
WHERE creator_id = 'user1';

--16
--Retrieve the Number of Followers for Each User:
SELECT u.username, COUNT(f.follower_id) AS follower_count
FROM Users u
LEFT JOIN Followers f ON u.username = f.followed_id
GROUP BY u.username;

--17
--Retrieve All Tags Associated with a Specific User Profile
SELECT * FROM Tags
WHERE page_id = 1;

--18
--Retrieve All Users Who Have Liked a Specific Reel
SELECT rl.username, rl.like_date
FROM ReelLikes rl
WHERE rl.reel_id = 1;

--19
--Retrieve All Users Who Have Accessed a Specific Post
SELECT pa.username, pa.access_date
FROM PostAccesses pa
WHERE pa.post_id = 1;

