-- Step 1: Add a New Column
-- Adding a new column 'birthdate' to the 'Users' table
ALTER TABLE Users ADD birthdate DATE;

-- Usage example: Insert new users with birthdate
INSERT INTO Users (username, first_name, last_name, city, password, gender, birthdate) VALUES 
('user107', 'Frank', 'Miller', 'Boston', 'passwordFrank', 'Male', '1990-05-15'),
('user108', 'Grace', 'Hopper', 'San Francisco', 'passwordGrace', 'Female', '1985-12-09');

-- Verify the insertions
SELECT * FROM Users WHERE username IN ('user107', 'user108');

-- Step 2: Update Rows
-- Changing the name of the user with username 'user100'
UPDATE Users SET first_name = 'Alice', last_name = 'Johnson' WHERE username = 'user100';

-- Changing the city of user with username 'user101'
UPDATE Users SET city = 'San Diego' WHERE username = 'user101';

-- Verify the updates
SELECT * FROM Users WHERE username IN ('user100', 'user101');

-- Step 3: Delete Specific Rows
-- Delete dependent rows in the Highlights table first
DELETE FROM Highlights WHERE user_id = 'user104';

DELETE FROM PostComments WHERE commenter_id = 'user104';

DELETE FROM Followers WHERE follower_id = 'user104' OR followed_id = 'user104';

-- Now delete the user
DELETE FROM Users WHERE username = 'user104';

-- Verify the deletion
SELECT * FROM Users WHERE username = 'user104';



-- Step 4: Add New Custom Constraints
-- Ensure no duplicate emails before adding the custom unique constraint
DELETE FROM UserEmails WHERE user_email IN (
    SELECT user_email FROM UserEmails GROUP BY user_email HAVING COUNT(*) > 1
);

-- Add a custom constraint to ensure user_email is unique
ALTER TABLE UserEmails ADD CONSTRAINT CK_UserEmails_Unique_Email UNIQUE (user_email);

-- Usage example: Insert a new user email ensuring uniqueness
INSERT INTO UserEmails (user_email, user_id) VALUES ('frank.miller@example.com', 'user105');

-- Verify the insertion
SELECT * FROM UserEmails WHERE user_email = 'frank.miller@example.com';

-- Adding a custom constraint to ensure city is not NULL
UPDATE Users SET city = 'Unknown' WHERE city IS NULL;
ALTER TABLE Users ADD CONSTRAINT CK_Users_City_Not_Null CHECK (city IS NOT NULL);

-- Verify that there are no NULL cities
SELECT * FROM Users WHERE city IS NULL;

-- Adding a custom foreign key constraint to HighlightAccesses
ALTER TABLE HighlightAccesses
ADD CONSTRAINT FK_HighlightAccesses_HighlightId
FOREIGN KEY (highlight_id) REFERENCES Highlights(highlight_id);

-- Verify the addition
SELECT * FROM sys.foreign_keys WHERE parent_object_id = OBJECT_ID('HighlightAccesses');

-- Step 5: Remove Custom Constraints
-- Remove the custom foreign key constraint from HighlightAccesses
ALTER TABLE HighlightAccesses
DROP CONSTRAINT FK_HighlightAccesses_HighlightId;

-- Verify the removal
SELECT * FROM sys.foreign_keys WHERE parent_object_id = OBJECT_ID('HighlightAccesses');

-- Step 6: Update Constraints
-- Identifying the actual foreign key constraint name on the 'Stories' table
SELECT constraint_name FROM information_schema.table_constraints WHERE table_name = 'Stories' AND constraint_type = 'FOREIGN KEY';

-- Assuming the constraint name is 'FK_Stories_HighlightId'
-- Dropping the identified foreign key constraint
ALTER TABLE Stories DROP CONSTRAINT FK_Stories_HighlightId;

-- Adding the foreign key constraint with ON DELETE CASCADE
ALTER TABLE Stories ADD CONSTRAINT FK_Stories_HighlightId_New FOREIGN KEY (highlight_id) REFERENCES Highlights(highlight_id) ON DELETE CASCADE;

-- Verify the new constraint
SELECT * FROM sys.foreign_keys WHERE parent_object_id = OBJECT_ID('Stories');

-- Usage example: Delete a highlight and see cascade delete in action
-- Insert a highlight and a story to demonstrate the cascade delete
INSERT INTO Highlights (highlight_id, user_id, publication_time, highlight_type, likers_list) VALUES 
(1000, 'user105', '2024-01-01 10:00:00', 'photo', 'user101,user102');

INSERT INTO Stories (story_id, highlight_id, end_date, story_type, location, view_count, publication_datetime, user_id) VALUES 
(203, 1000, '2024-01-02 10:00:00', 'image', 'New York', 150, '2024-01-01 10:00:00', 'user105');

-- Delete the highlight and verify cascade delete
DELETE FROM Highlights WHERE highlight_id = 1000;

-- Verify that the story has been deleted due to the cascade delete
SELECT * FROM Stories WHERE highlight_id = 1000;