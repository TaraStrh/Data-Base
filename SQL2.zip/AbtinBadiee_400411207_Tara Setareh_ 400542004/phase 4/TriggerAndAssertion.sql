use Project

-- Trigger to prevent insertion of users with a blank first name
CREATE TRIGGER trg_check_first_name
ON Users
FOR INSERT
AS
BEGIN
    IF EXISTS (SELECT * FROM inserted WHERE first_name = '')
    BEGIN
        RAISERROR ('First name cannot be blank', 16, 1);
        ROLLBACK TRANSACTION;
    END
END;



-- Trigger to update the last_update column on update of a user's details
ALTER TABLE Users ADD last_update DATETIME;

CREATE TRIGGER trg_update_last_update
ON Users
FOR UPDATE
AS
BEGIN
    UPDATE Users
    SET last_update = GETDATE()
    FROM Users u
    INNER JOIN inserted i ON u.username = i.username;
END;

--Trigger to prevent deletion of users who have associated posts

CREATE TRIGGER trg_prevent_user_deletion
ON Users
INSTEAD OF DELETE
AS
BEGIN
    IF EXISTS (SELECT * FROM Users u INNER JOIN Posts p ON u.username = p.poster_id WHERE u.username IN (SELECT username FROM deleted))
    BEGIN
        RAISERROR ('Cannot delete user with associated posts', 16, 1);
        ROLLBACK TRANSACTION;
    END
    ELSE
    BEGIN
        DELETE FROM Users WHERE username IN (SELECT username FROM deleted);
    END
END;


--Prevent Insertion of Duplicate Emails in UserEmails
CREATE TRIGGER trg_prevent_duplicate_emails
ON UserEmails
FOR INSERT
AS
BEGIN
    IF EXISTS (
        SELECT 1 
        FROM inserted i
        JOIN UserEmails ue ON i.user_email = ue.user_email
    )
    BEGIN
        RAISERROR ('Cannot insert duplicate email address', 16, 1);
        ROLLBACK TRANSACTION;
    END
END;


-- Set Default Value for city Column on Insert in Users
CREATE TRIGGER trg_set_default_city
ON Users
FOR INSERT
AS
BEGIN
    UPDATE Users
    SET city = 'Unknown'
    FROM Users u
    INNER JOIN inserted i ON u.username = i.username
    WHERE i.city IS NULL;
END;

-- Trigger to update view count when a story is accessed:
CREATE TRIGGER trg_update_story_view_count
ON StoryAccesses
FOR INSERT
AS
BEGIN
    UPDATE Stories
    SET view_count = view_count + 1
    FROM Stories s
    INNER JOIN inserted i ON s.story_id = i.story_id;
END;

--Assertion to ensure the birthdate is not in the future:
ALTER TABLE Users ADD CONSTRAINT CK_Users_Birthdate CHECK (birthdate <= GETDATE());

--Assertion to ensure view count is non-negative:
ALTER TABLE Stories ADD CONSTRAINT CK_Stories_ViewCount_NonNegative CHECK (view_count >= 0);

-- Assertion to ensure like count is non-negative:
ALTER TABLE Posts ADD CONSTRAINT CK_Posts_LikeCount_NonNegative CHECK (like_count >= 0);
