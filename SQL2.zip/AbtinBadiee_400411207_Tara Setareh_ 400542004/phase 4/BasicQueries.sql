use Project

--1
--Insert a new user
INSERT INTO Users (username, first_name, last_name, city, password, gender, sender_id)
VALUES ('johndoe', 'John', 'Doe', 'New York', 'password123', 'Male', NULL);
--Retrieve all users
SELECT * FROM Users;
--Update a user's city

--2
UPDATE Users
SET city = 'Los Angeles'
WHERE username = 'johndoe';

--3
--Delete a user
DELETE FROM Users
WHERE username = 'johndoe';

--4
--Insert a new highlight
INSERT INTO Highlights (highlight_id, user_id, publication_time, highlight_type, likers_list)
VALUES (100, 'johndoe', '2024-05-18 12:00:00', 'photo', 'user1,user2,user3');
--Retrieve highlights for a specific user
SELECT * FROM Highlights
WHERE user_id = 'johndoe';

--5
--Log a user's access to a highlight
INSERT INTO HighlightAccesses (access_date, username, highlight_id)
VALUES ('2024-05-18 12:05:00', 'johndoe', 1);
--Retrieve all accesses to a specific highlight
SELECT * FROM HighlightAccesses
WHERE highlight_id = 1;

--6
--Insert a new story
INSERT INTO Stories (story_id, highlight_id, end_date, story_type, location, view_count, publication_datetime, user_id)
VALUES (11, 1, '2024-05-19 12:00:00', 'image', 'New York', 100, '2024-05-18 12:00:00', 'johndoe');
--Retrieve stories for a specific highlight
SELECT * FROM Stories
WHERE highlight_id = 1;


--7
--Log a like on a story
INSERT INTO StoryLikes (like_date, username, story_id)
VALUES ('2024-05-18 12:10:00', 'johndoe', 1);
--Retrieve all likes on a specific story
SELECT * FROM StoryLikes
WHERE story_id = 1;


--8
--Insert a new contact for a user
INSERT INTO UserContacts (user_contact_number, user_id, contact_number)
VALUES ('1234567890', 'johndoe', '0987654321');
--Retrieve all contacts for a specific user
SELECT * FROM UserContacts
WHERE user_id = 'johndoe';


--9
-- Insert a new post
INSERT INTO Posts (post_id, poster_id, post_type, post_content, publication_date, comment_count, like_count, post_count, location, username)
VALUES (11, 'johndoe', 'text', 'This is a new post', '2024-05-18 12:00:00', 0, 0, 1, 'New York', 'johndoe');
-- Retrieve posts for a specific user
SELECT * FROM Posts
WHERE username = 'johndoe';

--10
--Log a like on a post
INSERT INTO PostLikes (like_date, username, post_id)
VALUES ('2024-05-18 12:15:00', 'johndoe', 1);
-- Retrieve all likes on a specific post
SELECT * FROM PostLikes
WHERE post_id = 1;

--11
-- Insert a new note:
INSERT INTO Notes (note_id, content, publication_date, end_date, username, creator_id)
VALUES (11, 'This is a note', '2024-05-18 12:00:00', '2024-06-18 12:00:00', 'johndoe', 'johndoe');
-- Retrieve notes created by a specific user
SELECT * FROM Notes
WHERE creator_id = 'johndoe';

--12
--Insert a new user profile:
INSERT INTO UserProfiles (page_id, username, follower_count, following_count, biography)
VALUES (11, 'johndoe', 100, 50, 'This is John Doe�s biography.');
-- Retrieve profile information for a specific user
SELECT * FROM UserProfiles
WHERE username = 'johndoe';

--13
--Insert a new tag
INSERT INTO Tags (tag_id, tag_date, username, page_id, page)
VALUES (11, '2024-05-18 12:00:00', 'johndoe', 1, 'ProfilePage');
--Retrieve tags created by a specific user
SELECT * FROM Tags
WHERE username = 'johndoe';

--14
--Insert a new reel:
INSERT INTO Reels (reel_id, view_count, like_count, comment_count, publication_date, reel_content, username, creator_id)
VALUES (11, 100, 10, 5, '2024-05-18 12:00:00', 'This is a reel content', 'johndoe', 'johndoe');
-- Retrieve reels created by a specific user
SELECT * FROM Reels
WHERE creator_id = 'johndoe';

--15
-- Insert a new friend request:
INSERT INTO FriendRequests (request_date, receiver_id, sender_id)
VALUES ('2024-05-18 12:00:00', 'user1', 'johndoe');
--Retrieve friend requests received by a specific user
SELECT * FROM FriendRequests
WHERE receiver_id = 'user1';

-- 16
-- Insert a new request response
INSERT INTO RequestResponses (response_status, response_date, receiver_id, sender_id)
VALUES ('Accepted', '2024-05-18 12:05:00', 'user1', 'johndoe');
-- Retrieve responses to friend requests sent by a specific user
SELECT * FROM RequestResponses
WHERE sender_id = 'johndoe';

