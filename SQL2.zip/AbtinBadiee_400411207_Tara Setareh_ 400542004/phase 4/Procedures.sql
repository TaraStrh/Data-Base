use Project

--Procedure to add a new user:
CREATE PROCEDURE sp_add_user
    @username VARCHAR(100),
    @first_name VARCHAR(100),
    @last_name VARCHAR(100),
    @city VARCHAR(100),
    @password VARCHAR(255),
    @gender VARCHAR(10),
    @birthdate DATE
AS
BEGIN
    INSERT INTO Users (username, first_name, last_name, city, password, gender, birthdate)
    VALUES (@username, @first_name, @last_name, @city, @password, @gender, @birthdate);
END;

-- Procedure to update a user's city:
CREATE PROCEDURE sp_update_user_city
    @username VARCHAR(100),
    @new_city VARCHAR(100)
AS
BEGIN
    UPDATE Users
    SET city = @new_city
    WHERE username = @username;
END;

--  Procedure to delete a user and their associated data:

CREATE PROCEDURE sp_delete_user
    @username VARCHAR(100)
AS
BEGIN
    DELETE FROM Followers WHERE follower_id = @username OR followed_id = @username;
    DELETE FROM Highlights WHERE user_id = @username;
    DELETE FROM Posts WHERE poster_id = @username;
    DELETE FROM Users WHERE username = @username;
END;