use Project

SELECT * FROM vw_user_latest_highlight;

EXEC sp_add_user 'cfvgbhnj', 'John', 'Doe', 'Miami', 'passwordJohn', 'Male', '1988-04-20';

SELECT dbo.fn_get_follower_count('user105') AS FollowerCount;

SELECT dbo.fn_get_follower_count('user105') AS FollowerCount;

EXEC sp_update_user_city 'user107', 'Orlando';

SELECT dbo.fn_get_age('1990-05-15') AS Age;

SELECT * FROM vw_posts_with_comment_count;

EXEC sp_delete_user 'user107';

SELECT dbo.fn_get_post_count('user105') AS PostCount;

SELECT * FROM vw_users_with_follower_count;
