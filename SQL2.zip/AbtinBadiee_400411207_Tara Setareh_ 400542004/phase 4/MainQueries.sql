-- Main Queries
-- Insert test data

use Project

INSERT INTO Users (username, first_name, last_name, city, password, gender) VALUES 
('user_11000', 'John', 'Doe', 'New York', 'password123', 'Male'),
('user_11001', 'Jane', 'Smith', 'Los Angeles', 'password123', 'Female'),
('user_11002', 'Alice', 'Johnson', 'Chicago', 'password123', 'Female'),
('user_11003', 'Bob', 'Williams', 'Houston', 'password123', 'Male'),
('user_11004', 'Charlie', 'Brown', 'Phoenix', 'password123', 'Male');

INSERT INTO UserProfiles (page_id, username, follower_count, following_count, biography) VALUES 
(11000, 'user_11000', 150, 200, 'Bio for John Doe'),
(11002, 'user_11001', 50, 100, 'Bio for Jane Smith'),
(11003, 'user_11002', 120, 150, 'Bio for Alice Johnson'),
(11004, 'user_11003', 80, 110, 'Bio for Bob Williams'),
(11005, 'user_11004', 30, 40, 'Bio for Charlie Brown');

INSERT INTO Posts (post_id, poster_id, post_type, post_content, publication_date, comment_count, like_count, post_count, location, username) VALUES 
(11001, 'user_11000', 'type1', 'Content of post 1', '2024-05-20 12:00:00', 10, 15, 1, 'Location1', 'user_11000'),
(11002, 'user_11001', 'type2', 'Content of post 2', '2024-05-21 13:00:00', 5, 10, 1, 'Location2', 'user_11001'),
(11003, 'user_11002', 'type1', 'Content of post 3', '2024-05-22 14:00:00', 8, 12, 1, 'Location3', 'user_11002'),
(11004, 'user_11003', 'type3', 'Content of post 4', '2024-05-23 15:00:00', 12, 18, 1, 'Location4', 'user_11003'),
(11005, 'user_11004', 'type2', 'Content of post 5', '2024-05-24 16:00:00', 6, 9, 1, 'Location5', 'user_11004');

INSERT INTO PostComments(comment_id, post_id, commenter_id, comment_text, comment_date) VALUES 
(11001, 11001, 'user_11001', 'Comment on post 1 by user_11001', '2024-05-20 12:30:00'),
(11002, 11002, 'user_11002', 'Comment on post 2 by user_11002', '2024-05-21 13:30:00'),
(11003, 11003, 'user_11003', 'Comment on post 3 by user_11003', '2024-05-22 14:30:00'),
(11004, 11004, 'user_11004', 'Comment on post 4 by user_11004', '2024-05-23 15:30:00'),
(11005, 11005, 'user_11000', 'Comment on post 5 by user_11000', '2024-05-24 16:30:00');

INSERT INTO Highlights (highlight_id, user_id, publication_time, highlight_type, likers_list) VALUES 
(11001, 'user_11000', '2024-05-20 12:00:00', 'type1', 'user_11001,user_11002'),
(11002, 'user_11001', '2024-05-21 13:00:00', 'type2', 'user_11003,user_11004');

INSERT INTO HighlightAccesses (access_date, username, highlight_id) VALUES 
('2024-05-20 12:15:00', 'user_11002', 11001),
('2024-05-21 13:15:00', 'user_11003', 11002);

INSERT INTO Stories (story_id, highlight_id, end_date, story_type, location, view_count, publication_datetime, user_id) VALUES 
(11001, 11001, '2024-05-20 14:00:00', 'story_type1', 'location1', 100, '2024-05-20 12:00:00', 'user_11000'),
(11002, 11002, '2024-05-21 15:00:00', 'story_type2', 'location2', 150, '2024-05-21 13:00:00', 'user_11001');

INSERT INTO StoryLikes (like_date, username, story_id) VALUES 
('2024-05-20 12:30:00', 'user_11002', 11001),
('2024-05-21 13:30:00', 'user_11003', 11002);

INSERT INTO StoryAccesses (access_date, username, story_id) VALUES 
('2024-05-20 12:45:00', 'user_11004', 11001),
('2024-05-21 13:45:00', 'user_11000', 11002);

INSERT INTO Reels (reel_id, view_count, like_count, comment_count, publication_date, reel_content, username, creator_id) VALUES 
(11001, 100, 10, 5, '2024-05-20 12:00:00', 'Reel content 1', 'user_11000', 'user_11000'),
(11002, 200, 20, 10, '2024-05-21 13:00:00', 'Reel content 2', 'user_11001', 'user_11001');

INSERT INTO ReelLikes (like_date, username, reel_id) VALUES 
('2024-05-20 12:30:00', 'user_11002', 11001),
('2024-05-21 13:30:00', 'user_11003', 11002);

INSERT INTO ReelAccesses (access_date, username, reel_id) VALUES 
('2024-05-20 12:45:00', 'user_11004', 11001),
('2024-05-21 13:45:00', 'user_11000', 11002);

INSERT INTO FriendRequests (request_date, receiver_id, sender_id) VALUES 
('2024-05-20 12:00:00', 'user_11001', 'user_11000'),
('2024-05-21 13:00:00', 'user_11002', 'user_11001');

INSERT INTO RequestResponses (response_status, response_date, receiver_id, sender_id) VALUES 
('Accepted', '2024-05-20 12:30:00', 'user_11001', 'user_11000'),
('Rejected', '2024-05-21 13:30:00', 'user_11002', 'user_11001');

INSERT INTO Followers (follower_id, followed_id, follow_date) VALUES 
('user_11000', 'user_11001', '2024-05-20'),
('user_11001', 'user_11002', '2024-05-21');

-- Nested Queries
-- Query 1: Retrieve all posts by users who have more than 100 followers
SELECT * 
FROM Posts 
WHERE poster_id IN (
    SELECT username 
    FROM UserProfiles 
    WHERE follower_count > 100
);

-- Query 2: Find all comments on posts made by user 'user_11001'
SELECT * 
FROM PostComments 
WHERE post_id IN (
    SELECT post_id 
    FROM Posts 
    WHERE poster_id = 'user_11001'
);

-- Query 3: List all users who have accessed any highlight created by users from New York
SELECT DISTINCT username 
FROM HighlightAccesses 
WHERE highlight_id IN (
    SELECT highlight_id 
    FROM Highlights 
    WHERE user_id IN (
        SELECT username 
        FROM Users 
        WHERE city = 'New York'
    )
);

-- Query 4: Get all stories viewed by users who follow 'user_11001'
SELECT * 
FROM Stories 
WHERE story_id IN (
    SELECT story_id 
    FROM StoryAccesses 
    WHERE username IN (
        SELECT follower_id 
        FROM Followers 
        WHERE followed_id = 'user_11001'
    )
);

-- Query 5: Find all users who have liked posts from users who liked reel with ID 1
SELECT DISTINCT username 
FROM PostLikes 
WHERE post_id IN (
    SELECT post_id 
    FROM Posts 
    WHERE poster_id IN (
        SELECT username 
        FROM ReelLikes 
        WHERE reel_id = 1
    )
);

-- Query 6: Get all reels liked by users who have liked a post of type 'video'
SELECT * 
FROM Reels 
WHERE reel_id IN (
    SELECT reel_id 
    FROM ReelLikes 
    WHERE username IN (
        SELECT username 
        FROM PostLikes 
        WHERE post_id IN (
            SELECT post_id 
            FROM Posts 
            WHERE post_type = 'video'
        )
    )
);

-- Query 7: List all posts commented on by users who have posted stories in 'location1'
SELECT * 
FROM Posts 
WHERE post_id IN (
    SELECT post_id 
    FROM PostComments 
    WHERE commenter_id IN (
        SELECT user_id 
        FROM Stories 
        WHERE location = 'location1'
    )
);

-- Query 8: Find all notes accessed by users who have liked a story from user 'user_11009'
SELECT * 
FROM Notes 
WHERE note_id IN (
    SELECT note_id 
    FROM NoteAccesses 
    WHERE username IN (
        SELECT username 
        FROM StoryLikes 
        WHERE story_id IN (
            SELECT story_id 
            FROM Stories 
            WHERE user_id = 'user_11009'
        )
    )
);

-- Query 9: Get all users who have sent friend requests to users who have posted highlights of type 'type2'
SELECT DISTINCT sender_id 
FROM FriendRequests 
WHERE receiver_id IN (
    SELECT user_id 
    FROM Highlights 
    WHERE highlight_type = 'type2'
);

-- Query 10: List all users who have commented on posts of users followed by 'user_11004'
SELECT DISTINCT commenter_id 
FROM PostComments 
WHERE post_id IN (
    SELECT post_id 
    FROM Posts 
    WHERE poster_id IN (
        SELECT followed_id 
        FROM Followers 
        WHERE follower_id = 'user_11004'
    )
);

-- Join Queries
-- Query 1: Retrieve user details along with their profile information
SELECT u.username, u.first_name, u.last_name, up.follower_count, up.following_count 
FROM Users u
JOIN UserProfiles up ON u.username = up.username;

-- Query 2: Get all posts along with their likers' usernames
SELECT p.post_id, p.post_content, pl.username 
FROM Posts p
JOIN PostLikes pl ON p.post_id = pl.post_id;

-- Query 3: List all stories and their respective viewers
SELECT s.story_id, s.story_type, sa.username 
FROM Stories s
JOIN StoryAccesses sa ON s.story_id = sa.story_id;

-- Query 4: Find all users who have sent friend requests along with the receivers' details
SELECT fr.sender_id, fr.receiver_id, u.first_name, u.last_name 
FROM FriendRequests fr
JOIN Users u ON fr.receiver_id = u.username;

-- Query 5: Get all reels and their respective likers
SELECT r.reel_id, r.reel_content, rl.username 
FROM Reels r
JOIN ReelLikes rl ON r.reel_id = rl.reel_id;

-- Query 6: Retrieve posts along with the comments made on them
SELECT p.post_id, p.post_content, pc.comment_text 
FROM Posts p
JOIN PostComments pc ON p.post_id = pc.post_id;

-- Query 7: Get users and their friends' requests
SELECT u.username, fr.sender_id, fr.receiver_id 
FROM Users u
JOIN FriendRequests fr ON u.username = fr.receiver_id OR u.username = fr.sender_id;

-- Query 8: List highlights along with the users who accessed them
SELECT h.highlight_id, h.highlight_type, ha.username 
FROM Highlights h
JOIN HighlightAccesses ha ON h.highlight_id = ha.highlight_id;

-- Query 9: Retrieve notes and their creators
SELECT n.note_id, n.content, u.username 
FROM Notes n
JOIN Users u ON n.creator_id = u.username;

-- Query 10: Find all users and their stories along with the location of the stories
SELECT u.username, s.story_id, s.location 
FROM Users u
JOIN Stories s ON u.username = s.user_id;

