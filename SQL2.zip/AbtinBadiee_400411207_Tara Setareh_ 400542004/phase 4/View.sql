use Project

--View to show user details with their latest highlight:

CREATE VIEW vw_user_latest_highlight AS
SELECT u.username, u.first_name, u.last_name, u.city, h.highlight_id, h.publication_time
FROM Users u
LEFT JOIN Highlights h ON u.username = h.user_id
WHERE h.publication_time = (
    SELECT MAX(h2.publication_time)
    FROM Highlights h2
    WHERE h2.user_id = u.username
);


-- View to show posts with their comment count:
CREATE VIEW vw_posts_with_comment_count AS
SELECT 
    p.post_id, 
    p.poster_id, 
    p.post_type, 
    CAST(p.post_content AS VARCHAR(MAX)) AS post_content, 
    p.publication_date, 
    COUNT(pc.comment_id) AS comment_count
FROM 
    Posts p
LEFT JOIN 
    PostComments pc ON p.post_id = pc.post_id
GROUP BY 
    p.post_id, 
    p.poster_id, 
    p.post_type, 
    CAST(p.post_content AS VARCHAR(MAX)), 
    p.publication_date;

-- View to show users with their follower count:
CREATE VIEW vw_users_with_follower_count AS
SELECT u.username, u.first_name, u.last_name, u.city, COUNT(f.follower_id) AS follower_count
FROM Users u
LEFT JOIN Followers f ON u.username = f.followed_id
GROUP BY u.username, u.first_name, u.last_name, u.city;
