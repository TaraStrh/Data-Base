﻿use Project

CREATE Table Users (
	username VARCHAR(100) Primary key,
	first_name VARCHAR(100),
	last_name VARCHAR(100),
	city VARCHAR(100),
	password VARCHAR(255),
	gender VARCHAR(10),
);

-- Step 2: Add sender_id column
ALTER TABLE Users
ADD sender_id VARCHAR(100);

-- Step 3: Add foreign key constraint to sender_id
ALTER TABLE Users
ADD CONSTRAINT fk_sender
FOREIGN KEY (sender_id)
REFERENCES Users(username);

-- Step 4: Create Highlights table
CREATE TABLE Highlights (
    highlight_id INT PRIMARY KEY,
    user_id VARCHAR(100),
    publication_time DATETIME,
    highlight_type VARCHAR(50),
    likers_list TEXT,
    FOREIGN KEY (user_id) REFERENCES Users(username)
);
CREATE TABLE HighlightAccesses (
    access_date DATETIME,                         -- تاریخ دسترسی
    username VARCHAR(100),                        -- نام کاربری
    highlight_id INT,                             -- شناسھ ھایلایت
    PRIMARY KEY (username, highlight_id),         -- Composite primary key
    FOREIGN KEY (username) REFERENCES Users(username),      -- Foreign key for username
    FOREIGN KEY (highlight_id) REFERENCES Highlights(highlight_id) -- Foreign key for highlight_id
);


CREATE TABLE Stories (
    story_id INT  PRIMARY KEY,        
    highlight_id INT,                               
    end_date DATETIME,                               
    story_type VARCHAR(50),                         
    location VARCHAR(255),                          
    view_count INT,                                 
    publication_datetime DATETIME,                   
    user_id VARCHAR(100),                           
    FOREIGN KEY (highlight_id) REFERENCES Highlights(highlight_id),  
    FOREIGN KEY (user_id) REFERENCES Users(username)
);

CREATE TABLE StoryLikes (
    like_date DATETIME,                           -- تاریخ لایک
    username VARCHAR(100),                        -- نام کاربری
    story_id INT,                                 -- شناسھ استوری
    PRIMARY KEY (username, story_id),             -- Composite primary key
    FOREIGN KEY (username) REFERENCES Users(username),  -- Foreign key for username
    FOREIGN KEY (story_id) REFERENCES Stories(story_id) -- Foreign key for story_id
);

CREATE TABLE StoryAccesses (
    access_date DATETIME,                         -- تاریخ دسترسی
    username VARCHAR(100),                        -- نام کاربری
    story_id INT,                                 -- شناسھ استوری
    PRIMARY KEY (username, story_id),             -- Composite primary key
    FOREIGN KEY (username) REFERENCES Users(username),  -- Foreign key for username
    FOREIGN KEY (story_id) REFERENCES Stories(story_id) -- Foreign key for story_id
);


	CREATE TABLE UserContacts (
		user_contact_number VARCHAR(20), 
		user_id VARCHAR(100),             
		contact_number VARCHAR(20),       
		PRIMARY KEY (user_contact_number, user_id),  
		FOREIGN KEY (user_id) REFERENCES Users(username) 
	);

	CREATE TABLE UserEmails (
    user_email VARCHAR(255),         
    user_id VARCHAR(100),            
    PRIMARY KEY (user_email, user_id),  
    FOREIGN KEY (user_id) REFERENCES Users(username)
);

CREATE TABLE Posts (
    post_id INT PRIMARY KEY,       
    poster_id VARCHAR(100),                       
    post_type VARCHAR(50),                                            
    post_content TEXT,                            
    publication_date DATETIME,                    
    comment_count INT,                            
    like_count INT,                               
    post_count INT,                               
    location VARCHAR(255),                        
    username VARCHAR(100),                       
    FOREIGN KEY (poster_id) REFERENCES Users(username) 
);

CREATE TABLE PostLikes (
    like_date DATETIME,                          -- تاریخ لایک
    username VARCHAR(100),                       -- نام کاربری
    post_id INT,                                 -- شناسھ پست
    PRIMARY KEY (username, post_id),             -- Composite primary key
    FOREIGN KEY (username) REFERENCES Users(username),  -- Foreign key for username
    FOREIGN KEY (post_id) REFERENCES Posts(post_id)     -- Foreign key for post_id
);

CREATE TABLE PostAccesses (
    access_date DATETIME,                        -- تاریخ دسترسی
    username VARCHAR(100),                       -- نام کاربری
    post_id INT,                                 -- شناسھ پست
    PRIMARY KEY (username, post_id),             -- Composite primary key
    FOREIGN KEY (username) REFERENCES Users(username),  -- Foreign key for username
    FOREIGN KEY (post_id) REFERENCES Posts(post_id)     -- Foreign key for post_id
);

CREATE TABLE Notes (
    note_id INT  PRIMARY KEY,       -- شناسھ یادداشت
    content TEXT,                                 -- متن
    publication_date DATETIME,                    -- تاریخ انتشار
    end_date DATETIME,                            -- تاریخ اتمام
    username VARCHAR(100),                        -- نام کاربری
    creator_id VARCHAR(100),                      -- شناسھ ایجاد کننده
    FOREIGN KEY (creator_id) REFERENCES Users(username)    -- Foreign key for creator_id
);

CREATE TABLE NoteAccesses (
    access_date DATETIME,                        -- تاریخ دسترسی
    username VARCHAR(100),                       -- نام کاربری
    note_id INT,                                 -- شناسھ یادداشت
    PRIMARY KEY (username, note_id),             -- Composite primary key
    FOREIGN KEY (username) REFERENCES Users(username),  -- Foreign key for username
    FOREIGN KEY (note_id) REFERENCES Notes(note_id)     -- Foreign key for note_id
);

CREATE TABLE UserProfiles (
    page_id INT  PRIMARY KEY,					  -- شناسھ صفحه
    username VARCHAR(100),                        -- نام کاربری
    follower_count INT,                           -- تعداد دنبال شوندگان
    following_count INT,                          -- تعداد دنبال کنندگان
    biography TEXT,                               -- بیوگرافی
    FOREIGN KEY (username) REFERENCES Users(username) -- Foreign key for username
);

CREATE TABLE Tags (
    tag_id INT  PRIMARY KEY,       -- Unique identifier for each tag
    tag_date DATETIME,                           -- تاریخ تگ
    username VARCHAR(100),                       -- نام کاربری
    page_id INT,                                 -- شناسھ صفحه
    page TEXT,                                   -- صفحھ
    FOREIGN KEY (username) REFERENCES Users(username),  -- Foreign key for username
    FOREIGN KEY (page_id) REFERENCES UserProfiles(page_id) -- Foreign key for page_id
);


CREATE TABLE Reels (
    reel_id INT  PRIMARY KEY,       -- شناسھ ریلز
    view_count INT,                               -- تعداد مشاھده
    like_count INT,                               -- تعداد لایک
    comment_count INT,                            -- تعداد کامنت
    publication_date DATETIME,                    -- تاریخ انتشار
    reel_content TEXT,                            -- متن زیر ریلز
    username VARCHAR(100),                        -- نام کاربری
    creator_id VARCHAR(100),                      -- شناسھ ایجاد کننده
    FOREIGN KEY (creator_id) REFERENCES Users(username)    -- Foreign key for creator_id
);

CREATE TABLE ReelLikes (
    like_date DATETIME,                           -- تاریخ لایک
    username VARCHAR(100),                        -- نام کاربری
    reel_id INT,                                  -- شناسھ ریلز
    PRIMARY KEY (username, reel_id),              -- Composite primary key
    FOREIGN KEY (username) REFERENCES Users(username),  -- Foreign key for username
    FOREIGN KEY (reel_id) REFERENCES Reels(reel_id)     -- Foreign key for reel_id
);

CREATE TABLE ReelAccesses (
    access_date DATETIME,                         -- تاریخ دسترسی
    username VARCHAR(100),                        -- نام کاربری
    reel_id INT,                                  -- شناسھ ریلز
    PRIMARY KEY (username, reel_id),              -- Composite primary key
    FOREIGN KEY (username) REFERENCES Users(username),  -- Foreign key for username
    FOREIGN KEY (reel_id) REFERENCES Reels(reel_id)     -- Foreign key for reel_id
);

CREATE TABLE FriendRequests (
    request_date DATETIME,                        -- تاریخ ارسال درخواست
    receiver_id VARCHAR(100),                     -- شناسھ گیرنده
    sender_id VARCHAR(100),                       -- شناسھ فرستنده
    PRIMARY KEY (receiver_id, sender_id),         -- Composite primary key
    FOREIGN KEY (receiver_id) REFERENCES Users(username), -- Foreign key for receiver_id
    FOREIGN KEY (sender_id) REFERENCES Users(username)    -- Foreign key for sender_id
);


CREATE TABLE RequestResponses (
    response_status VARCHAR(10), -- رد یا قبول درخواست
    response_date DATETIME,                       -- تاریخ رد یا قبول درخواست
    receiver_id VARCHAR(100),                     -- شناسھ گیرنده
    sender_id VARCHAR(100),                       -- شناسھ فرستنده
    PRIMARY KEY (receiver_id, sender_id),         -- Composite primary key
    FOREIGN KEY (receiver_id) REFERENCES Users(username), -- Foreign key for receiver_id
    FOREIGN KEY (sender_id) REFERENCES Users(username)    -- Foreign key for sender_id
);

SELECT * FROM Users;
SELECT * FROM Highlights;
SELECT * FROM HighlightAccesses;
SELECT * FROM Stories;
SELECT * FROM StoryLikes;
SELECT * FROM StoryAccesses;
SELECT * FROM UserContacts;
SELECT * FROM UserEmails;
SELECT * FROM Posts;
SELECT * FROM PostLikes;
SELECT * FROM Notes;
SELECT * FROM NoteAccesses;
SELECT * FROM UserProfiles;
SELECT * FROM Tags;
SELECT * FROM Reels;
SELECT * FROM ReelLikes;
SELECT * FROM ReelAccesses;
SELECT * FROM FriendRequests;
SELECT * FROM RequestResponses;
